package com.base;

public class Hija {

}
