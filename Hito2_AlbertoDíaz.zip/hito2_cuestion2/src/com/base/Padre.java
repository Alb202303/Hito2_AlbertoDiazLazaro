package com.base;

public class Padre {

}
