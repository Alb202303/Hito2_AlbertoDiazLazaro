package base;

public class Main {

	public static void main(String[] args) {
		Paciente[] pacientes=new Paciente[6];
		
		
		//Creamos 3 objetos paciente
		pacientes[0]= new Paciente("12345678W", "Alberto", "D�az");
		pacientes[1]= new Paciente("12355678W", "Roberto", "S�nchez");
		pacientes[2]= new Paciente("12245678W", "Adri�n", "Rodr�guez");
		
		//Creamos 3 objetos cirujano
		pacientes[3]=new Cirujano("43546431S", "Sara", "S�nchez", 2222);
		pacientes[4]=new Cirujano("43226431S", "Alejandro", "D�az", 2211);
		pacientes[5]=new Cirujano("11546431S", "Iker", "G�mez", 2242);
		
		
		
		//Se imprimen por pantalla los resultados
		for(Paciente p:pacientes) {
			System.out.println("DNI: "+ p.getDNI()
			+" Nombre: "+p.getNombre() +
			" Apellidos: "+p.getApellidos());
			//aqui se crea el polimorfismo
		}
				

	}

}
