package base;

public class Cirujano extends Paciente {
	private int n�Colegiado;

	Cirujano(String dNICirujano, String nombreCirujano, String apellidosCirujano, int n�Colegiado) {
		super(dNICirujano, nombreCirujano, apellidosCirujano); 
		this.n�Colegiado=n�Colegiado;
			
		}
	
	public int getn�Colegiado() {
		return n�Colegiado;
	}

	public void setn�Colegiado(int n�Colegiado) {
		this.n�Colegiado = n�Colegiado;
	}
	
	
	
	

	
	
	
}
