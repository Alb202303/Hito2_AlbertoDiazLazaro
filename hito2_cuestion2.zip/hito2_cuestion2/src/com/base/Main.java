package com.base;

public class Main {

	public static void main(String[] args) {
		
		Hija hija1=new Hija("Laura", 12);
		
		hija1.saludar();

	}

}
