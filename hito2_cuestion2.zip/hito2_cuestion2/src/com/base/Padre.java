package com.base;

public abstract class Padre { //cuando la clase es abstracta, nunca se podr� instanciar
	
	//atributos
	private String nombre;
	private int edad;
	
	public Padre(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}
	
	//m�todo
	public void saludar() {
		System.out.println("Hola, soy el padre");
	}

	//getters y setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	
	

}
