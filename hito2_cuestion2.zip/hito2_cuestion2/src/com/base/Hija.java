package com.base;

public class Hija extends Padre {
	
	//atributos
	private String nombre2;
	private int edad2;
	
	//constructor
	public Hija(String nombre2, int edad2) {
		super(nombre2, edad2);
		this.nombre2 = nombre2;
		this.edad2 = edad2;
	}
	
	//m�todo
	@Override //override nos permite reescribir la funci�n que hemos creado en la clase Padre
	public void saludar() {
		System.out.println("Hola soy la hija");
	}

	//getters y setters
	public String getNombre2() {
		return nombre2;
	}

	public void setNombre2(String nombre2) {
		this.nombre2 = nombre2;
	}

	public int getEdad2() {
		return edad2;
	}

	public void setEdad2(int edad2) {
		this.edad2 = edad2;
	}

	
	

}
