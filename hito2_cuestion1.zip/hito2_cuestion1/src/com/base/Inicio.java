package com.base;

public class Inicio {

	public static void main(String[] args) {
		Trabajador trabajador1= new Trabajador("Juan", 20000, 24);
		trabajador1.fichaTrabajador();
	}

}
