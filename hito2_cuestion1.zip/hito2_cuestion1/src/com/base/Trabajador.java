package com.base;



public class Trabajador {
	
	//atributos
	private String nombre;
	private float salarioBruto;
	private int contratoTemporal;
	
	//constructor
	public Trabajador(String nombre, float salarioBruto, int contratoTemporal) 
	{
		this.nombre = nombre;
		this.salarioBruto = salarioBruto;
		this.contratoTemporal = contratoTemporal;
	}

	//getters y setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getSalarioBruto() {
		return salarioBruto;
	}

	public void setSalarioBruto(float salarioBruto) {
		this.salarioBruto = salarioBruto;
	}

	public int getContratoTemporal() {
		return contratoTemporal;
	}

	public void setContratoTemporal(int contratoTemporal) {
		this.contratoTemporal = contratoTemporal;
	}
	
	public void fichaTrabajador() {
		System.out.println("El trabajador es "+this.nombre+" ,su salario bruto es "+this.salarioBruto+" y tiene un contrato temporal de "+this.contratoTemporal);
	}
	

	
	
}